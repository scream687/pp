from flask import Flask, jsonify, request
import sqlite3
import pandas as pd
import os

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({"message": "YouTube Automation System is live!"})

@app.route('/trending')
def trending():
    try:
        conn = sqlite3.connect("enhanced_trending_data.db")
        df = pd.read_sql_query("SELECT * FROM trends ORDER BY date DESC LIMIT 10", conn)
        return df.to_json(orient="records")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/upload-log')
def logs():
    try:
        conn = sqlite3.connect("youtube_analytics.db")
        df = pd.read_sql_query("SELECT * FROM uploads ORDER BY date DESC LIMIT 10", conn)
        return df.to_json(orient="records")
    except Exception as e:
        return jsonify({"error": str(e)}), 500
